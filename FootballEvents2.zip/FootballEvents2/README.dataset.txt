# Football_Events > Augmented
https://universe.roboflow.com/navin-rv0wp/football_events

Provided by a Roboflow user
License: CC BY 4.0

